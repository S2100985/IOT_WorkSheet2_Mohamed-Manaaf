# 21076191_Submission 1



## Name
Morsecode transmitter and receiver

## Description
In the zip file you will find 4 files not including the readme, they are the receiver code and its hex and the transmitter code and its hex file. these codes contain programs for two microbits in which the transmitter can send morse code from its pin 1 to its receivers pin 2 through a crocodile tipped wire. you can see the dots or dashes on the led screen of the transmitter once you press button A. the duration of the button press will determine the output if its a dot or dash. for dot press for a time period less than 250 miliseconds and for dash press for a time period between 250 miliseconds and 500 milseconds. The receiver will receive the morse code as dots and dashes and convert it into text and the outcome will be displayed on the LED screen of the receiver.

## Installation
No software needs to be installed as this program was created online usng the python.microbit.org website.

## Support
There are resources on the microbit website such as examples or methods displayed that help create this code.

## Roadmap
No future releases

## Project status
the project status - it has been completed, no further changes will be made
